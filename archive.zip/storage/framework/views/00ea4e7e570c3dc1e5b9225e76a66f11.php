<?php $__env->startSection('title', 'Projects'); ?>

<?php $__env->startSection('content'); ?>

<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h1 class="h3 mb-0">Projects</h1>
        <a href="" class="btn btn-primary">New Project</a>
    </div>
    <div class="mb-4">
        <form method="POST" action="<?php echo e(url('/projects/store')); ?>">
            <?php echo csrf_field(); ?>

            <div class="row g-3">
                <div class="col-md-6">
                    <label for="title" class="form-label">Project Name</label>
                    <input
                        type="text"
                        id="title"
                        name="project_name"
                        class="form-control"
                        value=""
                        required
                    >
                </div>

                <div class="col-md-6">
                    <label for="tool_name" class="form-label">Tool Name</label>
                    <input
                        type="text"
                        id="tool_name"
                        name="tool"
                        class="form-control"
                        value=""
                    >
                </div>
            </div>

            <div class="mt-3 d-flex justify-content-end">
                <button type="submit" class="btn btn-primary">Create Project</button>
            </div>
        </form>
    </div>

    <?php if(isset($projects)): ?>
        <div class="row g-3">
            <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-6 col-lg-4">
                    <div class="card h-100">
                        <div class="card-body d-flex flex-column">
                            <h5 class="card-title mb-1"><?php echo e($project->name); ?></h5>
                            <p class="card-text text-muted mb-2"><?php echo e($project->tool); ?></p>
                        </div>
                    </div>
                </div>
                <hr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php else: ?>
        <div class="alert alert-info">
            No projects found. <a href="">Create your first project</a>.
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /workspaces/laravel-codespace-template/resources/views/projects.blade.php ENDPATH**/ ?>